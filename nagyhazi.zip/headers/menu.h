///Menu logic
int menu();
