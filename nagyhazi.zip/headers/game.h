///game logic
int game(int mode);
